from typing import List
import numpy as np

# Points (2D or 3D) and curves made of points
Point = np.array
Curve = List[Point]
